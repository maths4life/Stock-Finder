//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B3El-GfT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/ideas",
			"/journal",
			"/research",
			"/screener"
		],
		preloads: ["/assets/index-CvqVVgbt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CvqVVgbt.js"
		} }]
	},
	"/": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-MPCvuGdC.js",
			"/assets/skeleton-ByMrGK4D.js",
			"/assets/CompanyRow-cniZRckl.js",
			"/assets/Sparkline-BABZF6B8.js",
			"/assets/useDiscover-CvzIHc6O.js",
			"/assets/useCompaniesForSymbols-D4Ho_BEA.js",
			"/assets/Badge-hzFyH9Ui.js",
			"/assets/Skeletons-CJR5zV8X.js"
		]
	},
	"/ideas": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/ideas.tsx",
		children: void 0,
		preloads: [
			"/assets/ideas-zUccMyCO.js",
			"/assets/skeleton-ByMrGK4D.js",
			"/assets/EmptyState-C3QdI49z.js",
			"/assets/Sparkline-BABZF6B8.js",
			"/assets/useDiscover-CvzIHc6O.js",
			"/assets/useCompaniesForSymbols-D4Ho_BEA.js"
		]
	},
	"/journal": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CGhIDRxO.js",
			"/assets/skeleton-ByMrGK4D.js",
			"/assets/select-DJ2_8bf1.js",
			"/assets/EmptyState-C3QdI49z.js",
			"/assets/x-BUZN5Jqf.js",
			"/assets/useCompaniesForSymbols-D4Ho_BEA.js",
			"/assets/StatMetric-sWbshW4X.js"
		]
	},
	"/research": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/research.tsx",
		children: ["/research/$symbol"],
		preloads: [
			"/assets/research-DWR957XD.js",
			"/assets/skeleton-ByMrGK4D.js",
			"/assets/select-DJ2_8bf1.js",
			"/assets/Pagination-BQg7mTvw.js",
			"/assets/EmptyState-C3QdI49z.js",
			"/assets/CompanyRow-cniZRckl.js",
			"/assets/x-BUZN5Jqf.js",
			"/assets/Skeletons-CJR5zV8X.js"
		]
	},
	"/screener": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/screener.tsx",
		children: void 0,
		preloads: [
			"/assets/screener-B1LuA3yf.js",
			"/assets/skeleton-ByMrGK4D.js",
			"/assets/check-tsc5TwHJ.js",
			"/assets/select-DJ2_8bf1.js",
			"/assets/Pagination-BQg7mTvw.js",
			"/assets/EmptyState-C3QdI49z.js",
			"/assets/sparkles-BwnDqOy4.js",
			"/assets/Sparkline-BABZF6B8.js",
			"/assets/Badge-hzFyH9Ui.js",
			"/assets/Skeletons-CJR5zV8X.js",
			"/assets/StatMetric-sWbshW4X.js"
		]
	},
	"/research/$symbol": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/research.$symbol.tsx",
		children: void 0,
		preloads: [
			"/assets/research._symbol-CierfAAC.js",
			"/assets/check-tsc5TwHJ.js",
			"/assets/sparkles-BwnDqOy4.js",
			"/assets/Sparkline-BABZF6B8.js",
			"/assets/Badge-hzFyH9Ui.js",
			"/assets/StatMetric-sWbshW4X.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
