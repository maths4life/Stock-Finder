import { i as __toESM } from "../_runtime.mjs";
import { c as fetchCompanyPrices, d as searchCompanies, i as fetchCompanies, l as fetchWeeklyMarketIntelligence, o as fetchCompany, r as fetchAllCompanies, s as fetchCompanyAnalysis, u as queryKeys } from "./queryKeys-DTkxJIgL.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { C as ArrowRight, l as Search, m as LoaderCircle, n as TriangleAlert, u as RotateCcw } from "../_libs/lucide-react.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/skeleton-xomvX9R5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Paginated, filterable, sortable company list — the one hook the screener and research index both use. */
function useCompanies(params) {
	return useQuery({
		queryKey: queryKeys.companies.list(params),
		queryFn: () => fetchCompanies(params),
		placeholderData: keepPreviousData
	});
}
function useCompany(symbol) {
	return useQuery({
		queryKey: queryKeys.companies.detail(symbol ?? ""),
		queryFn: () => fetchCompany(symbol),
		enabled: Boolean(symbol),
		retry: false
	});
}
/** Debounced-at-call-site search, used by the command palette. */
function useCompanySearch(query) {
	return useQuery({
		queryKey: queryKeys.companies.search(query),
		queryFn: () => searchCompanies(query),
		enabled: query.trim().length > 0,
		placeholderData: keepPreviousData
	});
}
/** Full unfiltered list — only for deriving option sets like sector dropdowns. */
function useAllCompanies() {
	return useQuery({
		queryKey: queryKeys.companies.all,
		queryFn: fetchAllCompanies,
		staleTime: 300 * 1e3
	});
}
/** Research page's AI Research Report section (Module 6). Deliberately
* `retry: false` and its own query key, same convention as useCompany
* above — an unknown symbol should surface as a 404, not a spinner
* that retries forever. */
function useCompanyAnalysis(symbol) {
	return useQuery({
		queryKey: queryKeys.companies.analysis(symbol ?? ""),
		queryFn: () => fetchCompanyAnalysis(symbol),
		enabled: Boolean(symbol),
		retry: false
	});
}
/** Research page's Price History chart (Module 3). Same query key/fn pair
* used by the route loader's SSR prefetch — must stay identical to avoid
* a hydration mismatch. */
function useCompanyPrices(symbol, range = "6M") {
	return useQuery({
		queryKey: queryKeys.companies.prices(symbol ?? "", range),
		queryFn: () => fetchCompanyPrices(symbol, range),
		enabled: Boolean(symbol),
		retry: false
	});
}
/** Research page's Weekly Market Intelligence section (Module 7). Same
* `retry: false` / own-query-key convention as useCompanyAnalysis above. */
function useWeeklyMarketIntelligence(symbol) {
	return useQuery({
		queryKey: queryKeys.companies.weeklyMarketIntelligence(symbol ?? ""),
		queryFn: () => fetchWeeklyMarketIntelligence(symbol),
		enabled: Boolean(symbol),
		retry: false
	});
}
function useDebouncedValue(value, delayMs = 300) {
	const [debounced, setDebounced] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => setDebounced(value), delayMs);
		return () => clearTimeout(timer);
	}, [value, delayMs]);
	return debounced;
}
function CommandPalette() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const debouncedQ = useDebouncedValue(q, 150);
	const navigate = useNavigate();
	const { data: results = [], isFetching } = useCompanySearch(debouncedQ);
	(0, import_react.useEffect)(() => {
		const handler = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				setOpen((v) => !v);
			}
			if (e.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", handler);
		return () => window.removeEventListener("keydown", handler);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!open) setQ("");
	}, [open]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[100] bg-ink/20 backdrop-blur-sm flex items-start justify-center pt-[15vh] px-4",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onClick: (e) => e.stopPropagation(),
			className: "w-full max-w-xl bg-surface-raised rounded-xl ring-1 ring-hairline-strong shadow-popover overflow-hidden animate-fade-up",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-3 hairline-b",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-ink-subtle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							autoFocus: true,
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Find a company, thesis, screen…",
							className: "flex-1 bg-transparent outline-none text-sm placeholder:text-ink-subtle"
						}),
						isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 text-ink-subtle animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
							className: "text-[10px] font-mono text-ink-subtle bg-secondary px-1.5 py-0.5 rounded",
							children: "ESC"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[50vh] overflow-y-auto py-2",
					children: [
						q.trim().length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 py-8 text-center text-sm text-ink-muted",
							children: "Start typing to search companies"
						}),
						q.trim().length > 0 && results.length === 0 && !isFetching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 py-8 text-center text-sm text-ink-muted",
							children: "No matches"
						}),
						results.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setOpen(false);
								navigate({
									to: "/research/$symbol",
									params: { symbol: c.symbol }
								});
							},
							className: "w-full flex items-center justify-between px-4 py-2.5 hover:bg-secondary/60 transition-colors text-left group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs w-20 shrink-0 text-ink",
									children: c.symbol
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-ink-muted truncate",
									children: c.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline text-[10px] uppercase tracking-widest text-ink-subtle",
									children: c.sector
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 text-ink-subtle opacity-0 group-hover:opacity-100 transition-opacity" })]
							})]
						}, c.symbol))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 py-2 hairline-t flex items-center justify-between text-[10px] text-ink-subtle",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Navigate ↑↓" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⌘K to toggle" })]
				})
			]
		})
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var nav = [
	{
		to: "/",
		label: "Discover"
	},
	{
		to: "/research",
		label: "Research"
	},
	{
		to: "/screener",
		label: "Screener"
	},
	{
		to: "/ideas",
		label: "Ideas"
	},
	{
		to: "/journal",
		label: "Journal"
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isActive = (to) => to === "/" ? pathname === "/" : pathname === to || pathname.startsWith(to + "/");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink selection:bg-accent/15 selection:text-accent",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "sticky top-0 z-40 bg-paper/85 backdrop-blur-md hairline-b",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-7xl mx-auto px-6 h-14 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-center gap-1.5 font-semibold text-[15px] tracking-tight leading-none text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-6 rounded-md bg-accent text-accent-foreground grid place-items-center text-[11px] font-bold",
								children: "Q"
							}), "Quant"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden md:flex items-center gap-1",
							children: nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: n.to,
								className: cn("px-3 py-1.5 rounded-md text-sm font-medium transition-colors", isActive(n.to) ? "text-ink bg-secondary" : "text-ink-subtle hover:text-ink hover:bg-secondary/60"),
								children: n.label
							}, n.to))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => window.dispatchEvent(new KeyboardEvent("keydown", {
								key: "k",
								metaKey: true
							})),
							className: "flex items-center gap-2 px-2.5 py-1.5 rounded-md ring-1 ring-hairline bg-secondary/60 hover:bg-secondary transition-colors",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 text-ink-subtle" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline text-xs text-ink-muted",
									children: "Search companies…"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
									className: "text-[10px] font-mono text-ink-subtle bg-surface-raised ring-1 ring-hairline rounded px-1",
									children: "⌘K"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-8 rounded-full bg-secondary ring-1 ring-hairline grid place-items-center text-[11px] font-medium text-ink-muted",
							children: "AV"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:hidden flex items-center gap-1 px-4 pb-2.5 overflow-x-auto",
					children: nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: n.to,
						className: cn("px-3 py-1.5 rounded-md text-sm font-medium whitespace-nowrap transition-colors", isActive(n.to) ? "text-ink bg-secondary" : "text-ink-subtle hover:text-ink"),
						children: n.label
					}, n.to))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandPalette, {})
		]
	});
}
/** Consistent error state for any failed query. Every data-driven view should render this on `isError`. */
function ErrorState({ title = "Something went wrong", description = "We couldn't load this data. Please try again.", onRetry, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center text-center py-16 px-6 " + (className ?? ""),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "size-10 rounded-full bg-negative-soft grid place-items-center mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4.5 text-negative" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-ink",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-sm text-ink-muted max-w-sm",
				children: description
			}),
			onRetry && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onRetry,
				className: "mt-5 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md ring-1 ring-hairline text-sm font-medium text-ink hover:bg-secondary transition-colors",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), " Try again"]
			})
		]
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
//#endregion
export { useAllCompanies as a, useCompanyAnalysis as c, useWeeklyMarketIntelligence as d, cn as i, useCompanyPrices as l, ErrorState as n, useCompanies as o, Skeleton as r, useCompany as s, AppShell as t, useDebouncedValue as u };
