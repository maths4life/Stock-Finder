import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as cn } from "./skeleton-xomvX9R5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatMetric-CENENfS8.js
var import_jsx_runtime = require_jsx_runtime();
var sizeClasses = {
	sm: "text-sm",
	md: "text-lg",
	lg: "text-2xl"
};
var toneClasses = {
	positive: "text-positive",
	negative: "text-negative",
	neutral: "text-ink"
};
/** A single label/value stat block — the atomic unit reused by score rows, hero metrics, and journal stats. */
function StatMetric({ label, value, sub, tone, size = "md", highlight, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-mono uppercase tracking-widest text-ink-subtle",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 font-semibold tabular-nums leading-none", sizeClasses[size], highlight ? "text-accent" : "text-ink"),
				children: value
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 text-[11px] font-mono", tone ? toneClasses[tone] : "text-ink-muted"),
				children: sub
			})
		]
	});
}
//#endregion
export { StatMetric as t };
