import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as ChevronRight, v as ChevronLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Pagination-kita4qbt.js
var import_jsx_runtime = require_jsx_runtime();
/** Drop-in pagination for any list backed by a `Paginated<T>` response shape. */
function Pagination({ page, totalPages, total, pageSize, onPageChange, className }) {
	if (total === 0) return null;
	const start = (page - 1) * pageSize + 1;
	const end = Math.min(page * pageSize, total);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4 " + (className ?? ""),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-ink-subtle",
			children: [
				"Showing ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-ink font-medium",
					children: [
						start,
						"–",
						end
					]
				}),
				" of",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-ink font-medium",
					children: total
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => onPageChange(page - 1),
					disabled: page <= 1,
					className: "size-8 grid place-items-center rounded-md ring-1 ring-hairline text-ink-muted hover:bg-secondary disabled:opacity-40 disabled:pointer-events-none transition-colors",
					"aria-label": "Previous page",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-ink-muted px-2 tabular-nums",
					children: [
						"Page ",
						page,
						" of ",
						totalPages
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => onPageChange(page + 1),
					disabled: page >= totalPages,
					className: "size-8 grid place-items-center rounded-md ring-1 ring-hairline text-ink-muted hover:bg-secondary disabled:opacity-40 disabled:pointer-events-none transition-colors",
					"aria-label": "Next page",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
				})
			]
		})]
	});
}
//#endregion
export { Pagination as t };
