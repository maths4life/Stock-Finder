import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as cn } from "./skeleton-xomvX9R5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Badge-CspDgsYu.js
var import_jsx_runtime = require_jsx_runtime();
var toneClasses = {
	positive: "bg-positive-soft text-positive",
	negative: "bg-negative-soft text-negative",
	neutral: "bg-neutral-soft text-neutral",
	warning: "bg-[oklch(0.96_0.03_75)] text-[oklch(0.45_0.11_65)] dark:bg-[oklch(0.3_0.05_75)] dark:text-[oklch(0.85_0.1_75)]",
	muted: "bg-secondary text-ink-subtle"
};
function Badge({ tone = "muted", children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap", toneClasses[tone], className),
		children
	});
}
var VERDICT_TONE = {
	"Strong Conviction": "positive",
	Watch: "neutral",
	"Under Review": "warning",
	Pass: "muted"
};
function VerdictBadge({ verdict, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: VERDICT_TONE[verdict] ?? "neutral",
		className,
		children: verdict
	});
}
var SENTIMENT_TONE = {
	Bullish: "positive",
	Positive: "positive",
	Neutral: "neutral",
	Bearish: "negative"
};
function SentimentBadge({ sentiment, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: SENTIMENT_TONE[sentiment] ?? "neutral",
		className,
		children: sentiment
	});
}
var RATING_TONE = {
	"Strong Buy": "positive",
	Buy: "positive",
	Hold: "warning",
	Avoid: "negative"
};
/** Module 6's Strong Buy/Buy/Hold/Avoid rating — a distinct scale from
* VerdictBadge's Strong Conviction/Watch/Under Review/Pass above, so
* kept as its own component rather than overloading VERDICT_TONE. */
function RatingBadge({ rating, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: RATING_TONE[rating] ?? "neutral",
		className,
		children: rating
	});
}
var OUTLOOK_TONE = {
	Positive: "positive",
	Neutral: "neutral",
	Negative: "negative"
};
/** Module 7's Weekly Market Intelligence sector outlook -- a distinct,
* news-derived scale from SentimentBadge's score-derived Sector Pulse
* above, so kept as its own component rather than reusing SENTIMENT_TONE. */
function OutlookBadge({ outlook, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: OUTLOOK_TONE[outlook] ?? "neutral",
		className,
		children: outlook
	});
}
//#endregion
export { VerdictBadge as i, RatingBadge as n, SentimentBadge as r, OutlookBadge as t };
