import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Check, c as SearchX, o as Sparkles, s as SlidersHorizontal, u as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as useAllCompanies, i as cn, n as ErrorState, o as useCompanies, t as AppShell } from "./skeleton-xomvX9R5.mjs";
import { n as PageHeader, t as EmptyState } from "./EmptyState-CsxZQot_.mjs";
import { t as Sparkline } from "./Sparkline-tbvAtMJU.mjs";
import { t as StatMetric } from "./StatMetric-CENENfS8.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-D-nYRlkk.mjs";
import { n as CompanyRowListSkeleton } from "./Skeletons-CmAaAKuW.mjs";
import { t as Pagination } from "./Pagination-kita4qbt.mjs";
import { i as VerdictBadge } from "./Badge-CspDgsYu.mjs";
import { n as toQueryParams, t as DEFAULT_FILTERS } from "./screener-x33smxGB.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/radix-ui__react-slider.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/screener-BtmwnRVU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" })]
}));
Slider.displayName = Slider$1.displayName;
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
function whySelected(c) {
	const reasons = [];
	if (c.roe >= 20) reasons.push(`ROE of ${c.roe.toFixed(1)}%`);
	if (c.profitGrowthPct >= 20) reasons.push(`profit growth of ${c.profitGrowthPct.toFixed(1)}%`);
	if (c.aboveEma200) reasons.push("trading above its 200-day average");
	if (c.volumeBreakout) reasons.push("breaking out on volume");
	if (reasons.length === 0) return c.rationale;
	return `Qualified on ${reasons.join(", ")}.`;
}
function Screener() {
	const [filters, setFilters] = (0, import_react.useState)(DEFAULT_FILTERS);
	const [applied, setApplied] = (0, import_react.useState)(DEFAULT_FILTERS);
	const [page, setPage] = (0, import_react.useState)(1);
	const { data: allCompanies = [] } = useAllCompanies();
	const sectors = (0, import_react.useMemo)(() => ["All", ...new Set(allCompanies.map((c) => c.sector))], [allCompanies]);
	const query = useCompanies(toQueryParams(applied, page));
	const results = query.data?.items ?? [];
	const update = (key, value) => setFilters((prev) => ({
		...prev,
		[key]: value
	}));
	const applyFilters = () => {
		setApplied(filters);
		setPage(1);
	};
	const reset = () => {
		setFilters(DEFAULT_FILTERS);
		setApplied(DEFAULT_FILTERS);
		setPage(1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 py-12 pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "AI Stock Discovery",
			title: "Set your criteria. See only what qualifies.",
			description: "No lists of hundreds. High-conviction names, ranked by a transparent score — not a black box.",
			className: "mb-10"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-12 gap-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "col-span-12 lg:col-span-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl ring-1 ring-hairline bg-surface-raised p-6 lg:sticky lg:top-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5 text-ink-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-eyebrow text-ink-subtle",
									children: "Filters"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: reset,
								className: "flex items-center gap-1 text-[11px] text-ink-subtle hover:text-ink transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }), " Reset"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Sector" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: filters.sector,
									onValueChange: (v) => update("sector", v),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "w-full mt-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: sectors.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s,
										children: s
									}, s)) })]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, {
									label: "Fundamentals",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Minimum ROE",
											value: filters.minRoe,
											max: 40,
											unit: "%",
											onChange: (v) => update("minRoe", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Minimum ROCE",
											value: filters.minRoce,
											max: 45,
											unit: "%",
											onChange: (v) => update("minRoce", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Minimum EPS growth",
											value: filters.minEpsGrowth,
											max: 60,
											unit: "%",
											onChange: (v) => update("minEpsGrowth", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Minimum sales growth",
											value: filters.minSalesGrowth,
											max: 60,
											unit: "%",
											onChange: (v) => update("minSalesGrowth", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Maximum P/E",
											value: filters.maxPe,
											max: 200,
											unit: "x",
											onChange: (v) => update("maxPe", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Maximum Debt/Equity",
											value: filters.maxDebtToEquity,
											max: 3,
											step: .1,
											unit: "x",
											onChange: (v) => update("maxDebtToEquity", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
											label: "Minimum promoter holding",
											value: filters.minPromoterHolding,
											max: 80,
											unit: "%",
											onChange: (v) => update("minPromoterHolding", v)
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, {
									label: "Technicals",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckField, {
											label: "Above 200-day average",
											checked: filters.aboveEma200,
											onChange: (v) => update("aboveEma200", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckField, {
											label: "Above 50-day average",
											checked: filters.aboveEma50,
											onChange: (v) => update("aboveEma50", v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckField, {
											label: "Volume breakout",
											checked: filters.volumeBreakout,
											onChange: (v) => update("volumeBreakout", v)
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, {
									label: "Investment profile",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Risk level" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: filters.riskLevel,
										onValueChange: (v) => update("riskLevel", v),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "w-full mt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
											"Any",
											"Low",
											"Moderate",
											"High"
										].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: r,
											children: r
										}, r)) })]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Investment horizon" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: filters.horizon,
										onValueChange: (v) => update("horizon", v),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "w-full mt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Any",
												children: "Any"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "short",
												children: "≤ 6 months"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "medium",
												children: "6–12 months"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "long",
												children: "12+ months"
											})
										] })]
									})] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: applyFilters,
							className: "mt-8 w-full py-2.5 rounded-md bg-accent text-accent-foreground text-sm font-medium hover:brightness-110 transition-all",
							children: "Find Stocks"
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "col-span-12 lg:col-span-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-3 mb-6 hairline-b pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-heading-xl tabular-nums",
							children: query.data?.total ?? "–"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-ink-muted",
							children: [query.data?.total === 1 ? "company matches" : "companies match", " — ranked by overall score"]
						})]
					}),
					query.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyRowListSkeleton, { count: 6 }),
					query.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
						description: "Couldn't load screener results.",
						onRetry: () => query.refetch()
					}),
					query.isSuccess && results.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: SearchX,
						title: "No matches",
						description: "Loosen a filter and try again — most screens over-constrain on the first pass.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: reset,
							className: "text-sm font-medium text-accent hover:underline underline-offset-2",
							children: "Reset all filters"
						})
					}),
					query.isSuccess && results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: results.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultCard, { company: c }, c.symbol))
					}), query.data && query.data.totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
						className: "mt-6",
						page: query.data.page,
						totalPages: query.data.totalPages,
						total: query.data.total,
						pageSize: query.data.pageSize,
						onPageChange: setPage
					})] })
				]
			})]
		})]
	}) });
}
function ResultCard({ company: c }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/research/$symbol",
		params: { symbol: c.symbol },
		className: "block p-5 rounded-xl ring-1 ring-hairline bg-surface-raised hover:ring-hairline-strong hover:shadow-card-hover transition-all",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-[15px]",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, { verdict: c.verdict })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-[10px] text-ink-subtle",
						children: [
							c.exchange,
							":",
							c.symbol,
							" · ",
							c.sector
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-[13.5px] text-ink-muted leading-relaxed text-pretty flex items-start gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-accent shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: whySelected(c) })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-right shrink-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono text-sm tabular-nums",
						children: ["₹", c.price.toLocaleString("en-IN")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] font-mono tabular-nums " + (c.changePct >= 0 ? "text-positive" : "text-negative"),
						children: [
							c.changePct >= 0 ? "+" : "",
							c.changePct.toFixed(2),
							"%"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
						data: c.spark,
						tone: c.changePct >= 0 ? "positive" : "negative",
						width: 90,
						height: 28,
						className: "mt-2 ml-auto"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid grid-cols-3 sm:grid-cols-6 gap-4 hairline-t pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
					label: "Overall",
					value: c.overallScore.toFixed(0),
					highlight: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
					label: "Fundamental",
					value: c.fundamentalScore.toFixed(0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
					label: "Technical",
					value: c.technicalScore.toFixed(0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
					label: "Risk",
					value: c.riskLevel,
					size: "sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
					label: "Expected Return",
					value: `${c.expectedReturnPct}%`,
					size: "sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
					label: "Horizon",
					value: `${c.investmentHorizonMonths}mo`,
					size: "sm"
				})
			]
		})]
	});
}
function FieldLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[11px] font-medium text-ink-muted",
		children
	});
}
function FieldGroup({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hairline-t pt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-eyebrow text-ink-subtle mb-4",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-5",
			children
		})]
	});
}
function SliderField({ label, value, max, step = 1, unit, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between mb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-mono text-xs text-ink tabular-nums",
			children: [value, unit]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
		value: [value],
		max,
		step,
		onValueChange: ([v]) => onChange(v)
	})] });
}
function CheckField({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-center gap-2.5 cursor-pointer select-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
			checked,
			onCheckedChange: (v) => onChange(Boolean(v))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-ink",
			children: label
		})]
	});
}
//#endregion
export { Screener as component };
