import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { f as Outlet, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as SearchX, l as Search, t as X } from "../_libs/lucide-react.mjs";
import { n as ErrorState, o as useCompanies, t as AppShell, u as useDebouncedValue } from "./skeleton-xomvX9R5.mjs";
import { n as PageHeader, t as EmptyState } from "./EmptyState-CsxZQot_.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-D-nYRlkk.mjs";
import { t as CompanyRow } from "./CompanyRow-DlgaCuQp.mjs";
import { n as CompanyRowListSkeleton } from "./Skeletons-CmAaAKuW.mjs";
import { t as Pagination } from "./Pagination-kita4qbt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research-CXZK-7aD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchInput({ value, onChange, placeholder = "Search…", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative " + (className ?? ""),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-ink-subtle" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value,
				onChange: (e) => onChange(e.target.value),
				placeholder,
				className: "w-full pl-9 pr-9 py-2.5 rounded-md ring-1 ring-hairline bg-surface-raised text-sm placeholder:text-ink-subtle outline-none focus:ring-hairline-strong transition-colors"
			}),
			value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => onChange(""),
				className: "absolute right-3 top-1/2 -translate-y-1/2 text-ink-subtle hover:text-ink transition-colors",
				"aria-label": "Clear search",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})
		]
	});
}
function ResearchLayout() {
	if (useRouterState({ select: (s) => s.location.pathname }) === "/research") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchIndex, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
function ResearchIndex() {
	const [search, setSearch] = (0, import_react.useState)("");
	const [sort, setSort] = (0, import_react.useState)("overallScore");
	const [page, setPage] = (0, import_react.useState)(1);
	const query = useCompanies({
		search: useDebouncedValue(search, 250),
		sort,
		sortDirection: sort === "name" ? "asc" : "desc",
		page,
		pageSize: 8
	});
	const results = query.data?.items ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 py-12 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Research library",
				title: "Every company, understood in a minute.",
				className: "mb-10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row gap-3 mb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
					value: search,
					onChange: (v) => {
						setSearch(v);
						setPage(1);
					},
					placeholder: "Search by name or ticker…",
					className: "flex-1"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: sort,
					onValueChange: (v) => setSort(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-full sm:w-56",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "overallScore",
							children: "Sort: Overall score"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "name",
							children: "Sort: Name (A–Z)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "changePct",
							children: "Sort: Day change"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "marketCapCr",
							children: "Sort: Market cap"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "pe",
							children: "Sort: P/E"
						})
					] })]
				})]
			}),
			query.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyRowListSkeleton, { count: 8 }),
			query.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Couldn't load the research library.",
				onRetry: () => query.refetch()
			}),
			query.isSuccess && results.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: SearchX,
				title: "No companies match",
				description: "Try a different name or ticker."
			}),
			query.isSuccess && results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: results.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyRow, { company: c }, c.symbol)) }), query.data && query.data.totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
				className: "mt-6",
				page: query.data.page,
				totalPages: query.data.totalPages,
				total: query.data.total,
				pageSize: query.data.pageSize,
				onPageChange: setPage
			})] })
		]
	}) });
}
//#endregion
export { ResearchLayout as component };
