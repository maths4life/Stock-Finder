import { n as ApiError, t as API_URL } from "./queryKeys-DTkxJIgL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-CWU7X-1H.js
/** GET /journal-entries */
async function fetchJournalEntries() {
	const response = await fetch(`${API_URL}/journal-entries`);
	if (!response.ok) throw new ApiError("Failed to fetch journal entries", response.status);
	return response.json();
}
/** POST /journal-entries */
async function createJournalEntry(input) {
	const response = await fetch(`${API_URL}/journal-entries`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(input)
	});
	if (!response.ok) throw new ApiError(await safeErrorDetail(response) ?? "Failed to create journal entry", response.status);
	return response.json();
}
/** PUT /journal-entries/{id} */
async function updateJournalEntry(id, input) {
	const response = await fetch(`${API_URL}/journal-entries/${id}`, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(input)
	});
	if (!response.ok) throw new ApiError(await safeErrorDetail(response) ?? "Failed to update journal entry", response.status);
	return response.json();
}
/** DELETE /journal-entries/{id} */
async function deleteJournalEntry(id) {
	const response = await fetch(`${API_URL}/journal-entries/${id}`, { method: "DELETE" });
	if (!response.ok && response.status !== 204) throw new ApiError(await safeErrorDetail(response) ?? "Failed to delete journal entry", response.status);
}
/** FastAPI's HTTPException body is `{ detail: string }` — surface it in
* the toast/error UI instead of a generic message when present. */
async function safeErrorDetail(response) {
	try {
		const body = await response.json();
		return typeof body?.detail === "string" ? body.detail : null;
	} catch {
		return null;
	}
}
//#endregion
export { updateJournalEntry as i, deleteJournalEntry as n, fetchJournalEntries as r, createJournalEntry as t };
