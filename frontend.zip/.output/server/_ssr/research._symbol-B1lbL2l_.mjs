import { c as fetchCompanyPrices, l as fetchWeeklyMarketIntelligence, o as fetchCompany, s as fetchCompanyAnalysis, u as queryKeys } from "./queryKeys-DTkxJIgL.mjs";
import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research._symbol-B1lbL2l_.js
var $$splitComponentImporter = () => import("./research._symbol-5z1OvV0x.mjs");
var Route = createFileRoute("/research/$symbol")({
	loader: async ({ params, context }) => {
		await context.queryClient.ensureQueryData({
			queryKey: queryKeys.companies.detail(params.symbol),
			queryFn: () => fetchCompany(params.symbol)
		}).catch(() => void 0);
		await context.queryClient.ensureQueryData({
			queryKey: queryKeys.companies.prices(params.symbol, "6M"),
			queryFn: () => fetchCompanyPrices(params.symbol, "6M")
		}).catch(() => void 0);
		await context.queryClient.ensureQueryData({
			queryKey: queryKeys.companies.analysis(params.symbol),
			queryFn: () => fetchCompanyAnalysis(params.symbol)
		}).catch(() => void 0);
		await context.queryClient.ensureQueryData({
			queryKey: queryKeys.companies.weeklyMarketIntelligence(params.symbol),
			queryFn: () => fetchWeeklyMarketIntelligence(params.symbol)
		}).catch(() => void 0);
	},
	head: ({ params }) => ({ meta: [{ title: `${params.symbol} — Research | Quant` }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
