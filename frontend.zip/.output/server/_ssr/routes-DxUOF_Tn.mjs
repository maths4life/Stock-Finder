import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { S as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { i as cn, n as ErrorState, r as Skeleton, t as AppShell } from "./skeleton-xomvX9R5.mjs";
import { t as Sparkline } from "./Sparkline-tbvAtMJU.mjs";
import { i as useSectorPulse, n as useMarketIndicators, r as usePipeline, t as useDiscoverGroups } from "./useDiscover-C2lAHpZA.mjs";
import { t as useCompaniesForSymbols } from "./useCompaniesForSymbols-DhUzTuSh.mjs";
import { t as CompanyRow } from "./CompanyRow-DlgaCuQp.mjs";
import { t as CompanyCardGridSkeleton } from "./Skeletons-CmAaAKuW.mjs";
import { i as VerdictBadge, r as SentimentBadge } from "./Badge-CspDgsYu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DxUOF_Tn.js
var import_jsx_runtime = require_jsx_runtime();
/**
* The single card presentation used everywhere a company is shown as a
* self-contained tile (Discover's technical momentum grid, Screener
* results). Purely presentational — all data comes in via props so it can
* be fed straight from a `Company` API response.
*/
function CompanyCard({ company: c, footer, note, className }) {
	const positive = c.changePct >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/research/$symbol",
		params: { symbol: c.symbol },
		className: cn("group block p-5 rounded-xl ring-1 ring-hairline bg-surface-raised hover:ring-hairline-strong hover:shadow-card-hover transition-all", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4 mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-[15px] text-ink truncate",
							children: c.name
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-[11px] text-ink-subtle mt-0.5",
						children: [
							c.exchange,
							":",
							c.symbol,
							" · ",
							c.sector
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, {
					verdict: c.verdict,
					className: "shrink-0"
				})]
			}),
			note ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-muted leading-relaxed text-pretty mb-4 line-clamp-2",
				children: c.rationale
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
					data: c.spark,
					tone: positive ? "positive" : "negative",
					fill: true,
					width: 140,
					height: 36
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono text-sm tabular-nums",
						children: ["₹", c.price.toLocaleString("en-IN")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("text-[11px] font-mono tabular-nums", positive ? "text-positive" : "text-negative"),
						children: [
							positive ? "+" : "",
							c.changePct.toFixed(2),
							"%"
						]
					})]
				})]
			}),
			footer
		]
	});
}
var WEEKDAYS = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
];
var MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
function formatToday() {
	const d = /* @__PURE__ */ new Date();
	return `${WEEKDAYS[d.getUTCDay()]}, ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]}`;
}
function Discover() {
	const groupsQuery = useDiscoverGroups();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 py-12 pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-14 animate-fade-up",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-eyebrow text-accent mb-2",
					children: formatToday()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-display md:text-display-lg text-balance max-w-[22ch]",
					children: "Which companies deserve your attention today?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-base text-ink-muted max-w-xl leading-relaxed",
					children: "Eight companies surfaced across four narratives. Take twenty minutes. Add one to your pipeline, or move on."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-12 gap-x-12 gap-y-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "col-span-12 lg:col-span-8 space-y-16",
				children: [
					groupsQuery.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoverFeedSkeleton, {}),
					groupsQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
						description: "Couldn't load today's briefing.",
						onRetry: () => groupsQuery.refetch()
					}),
					groupsQuery.data?.map((group, gi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoverGroupSection, {
						group,
						index: gi
					}, group.id))
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "col-span-12 lg:col-span-4 space-y-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelinePreview, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectorPulseList, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketContextList, {})
				]
			})]
		})]
	}) });
}
function DiscoverGroupSection({ group, index }) {
	const { data: companies = [], isPending } = useCompaniesForSymbols(group.symbols);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "animate-fade-up",
		style: { animationDelay: `${index * 60}ms` },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between hairline-b pb-3 mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-eyebrow text-ink-subtle",
				children: group.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-sm text-ink-muted",
				children: group.tagline
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-[11px] font-mono text-ink-subtle",
				children: [group.symbols.length, " names"]
			})]
		}), isPending ? group.layout === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyCardGridSkeleton, { count: group.symbols.length }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full rounded-md" }) : group.layout === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 md:grid-cols-2 gap-5",
			children: companies.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyCard, { company: c }, c.symbol))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: companies.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyRow, { company: c }, c.symbol)) })]
	});
}
function PipelinePreview() {
	const { data: columns = [], isPending } = usePipeline();
	const { data: companies = [] } = useCompaniesForSymbols(columns.flatMap((c) => c.items.map((i) => i.symbol)));
	const companyBySymbol = new Map(companies.map((c) => [c.symbol, c]));
	const stageColor = {
		Watching: "bg-hairline-strong",
		Researching: "bg-[oklch(0.65_0.14_75)]",
		Conviction: "bg-positive"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 rounded-xl ring-1 ring-hairline bg-secondary/40 border-t-2 border-accent animate-fade-up",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-eyebrow text-ink-subtle",
					children: "Active Pipeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/ideas",
					className: "text-[11px] text-accent hover:underline underline-offset-2",
					children: "Full board"
				})]
			}),
			isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5",
				children: columns.flatMap((stage) => stage.items.map((item) => {
					const c = companyBySymbol.get(item.symbol);
					if (!c) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/research/$symbol",
						params: { symbol: item.symbol },
						className: "flex gap-4 group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1 rounded-full shrink-0 " + stageColor[stage.stage] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-widest text-ink-subtle font-medium",
									children: stage.stage
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium mt-0.5 group-hover:text-accent transition-colors",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-ink-subtle mt-1 truncate",
									children: [
										item.note,
										" · ",
										item.ago
									]
								})
							]
						})]
					}, item.symbol + stage.stage);
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/ideas",
				className: "mt-6 w-full py-2 px-3 flex items-center justify-center gap-2 rounded-md bg-accent text-accent-foreground text-sm font-medium hover:brightness-110 transition-all",
				children: ["Open Pipeline", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-3.5" })]
			})
		]
	});
}
function SectorPulseList() {
	const { data: sectors = [], isPending } = useSectorPulse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-eyebrow text-ink-subtle mb-3",
		children: "Top Sectors"
	}), isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }, i))
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: sectors.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-ink",
				children: s.sector
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SentimentBadge, { sentiment: s.sentiment })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-[12px] text-ink-muted leading-snug text-pretty",
			children: s.reason
		})] }, s.sector))
	})] });
}
function MarketContextList() {
	const { data: indicators = [], isPending } = useMarketIndicators();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-eyebrow text-ink-subtle mb-3",
		children: "Market Context"
	}), isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" }, i))
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "divide-y divide-hairline",
		children: indicators.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between items-baseline py-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-ink-muted",
				children: m.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-sm text-ink tabular-nums",
					children: m.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 text-[11px] font-mono " + (m.tone === "positive" ? "text-positive" : "text-ink-subtle"),
					children: m.change
				})]
			})]
		}, m.label))
	})] });
}
function DiscoverFeedSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-16",
		children: Array.from({ length: 2 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40 mb-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyCardGridSkeleton, { count: 2 })] }, i))
	});
}
//#endregion
export { Discover as component };
