import { u as queryKeys } from "./queryKeys-DTkxJIgL.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as fetchSectorPulse, n as fetchMarketIndicators, r as fetchPipeline, t as fetchDiscoverGroups } from "./market-wylECQS6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useDiscover-C2lAHpZA.js
function useDiscoverGroups() {
	return useQuery({
		queryKey: queryKeys.discoverGroups,
		queryFn: fetchDiscoverGroups
	});
}
function usePipeline() {
	return useQuery({
		queryKey: queryKeys.pipeline,
		queryFn: fetchPipeline
	});
}
function useSectorPulse() {
	return useQuery({
		queryKey: queryKeys.sectorPulse,
		queryFn: fetchSectorPulse
	});
}
function useMarketIndicators() {
	return useQuery({
		queryKey: queryKeys.marketIndicators,
		queryFn: fetchMarketIndicators
	});
}
//#endregion
export { useSectorPulse as i, useMarketIndicators as n, usePipeline as r, useDiscoverGroups as t };
