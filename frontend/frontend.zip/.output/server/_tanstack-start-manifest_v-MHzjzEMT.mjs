//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-MHzjzEMT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/ideas",
			"/journal",
			"/research",
			"/screener"
		],
		preloads: ["/assets/index-C-3JIxBy.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C-3JIxBy.js"
		} }]
	},
	"/": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DT0dapF2.js",
			"/assets/skeleton-PJmE7Cfs.js",
			"/assets/CompanyRow-BQmYwPLv.js",
			"/assets/Sparkline-BKQUAuxe.js",
			"/assets/useDiscover-C13rnjk9.js",
			"/assets/useCompaniesForSymbols-CgB3bOPI.js",
			"/assets/Badge-BqUx2r49.js",
			"/assets/Skeletons-CzYF9VRe.js"
		]
	},
	"/ideas": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/ideas.tsx",
		children: void 0,
		preloads: [
			"/assets/ideas-DbuUVvNL.js",
			"/assets/skeleton-PJmE7Cfs.js",
			"/assets/EmptyState-DOOH5pGY.js",
			"/assets/Sparkline-BKQUAuxe.js",
			"/assets/useDiscover-C13rnjk9.js",
			"/assets/useCompaniesForSymbols-CgB3bOPI.js"
		]
	},
	"/journal": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CxXydjDE.js",
			"/assets/skeleton-PJmE7Cfs.js",
			"/assets/EmptyState-DOOH5pGY.js",
			"/assets/useCompaniesForSymbols-CgB3bOPI.js",
			"/assets/StatMetric-Dr14DY54.js"
		]
	},
	"/research": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/research.tsx",
		children: ["/research/$symbol"],
		preloads: [
			"/assets/research-CtvZm1z5.js",
			"/assets/skeleton-PJmE7Cfs.js",
			"/assets/select-xbN-HiHd.js",
			"/assets/EmptyState-DOOH5pGY.js",
			"/assets/CompanyRow-BQmYwPLv.js",
			"/assets/Skeletons-CzYF9VRe.js"
		]
	},
	"/screener": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/screener.tsx",
		children: void 0,
		preloads: [
			"/assets/screener-CxXmuHFx.js",
			"/assets/skeleton-PJmE7Cfs.js",
			"/assets/check-BfWG19CS.js",
			"/assets/select-xbN-HiHd.js",
			"/assets/EmptyState-DOOH5pGY.js",
			"/assets/sparkles-CTxyKtAy.js",
			"/assets/Sparkline-BKQUAuxe.js",
			"/assets/Badge-BqUx2r49.js",
			"/assets/Skeletons-CzYF9VRe.js",
			"/assets/StatMetric-Dr14DY54.js"
		]
	},
	"/research/$symbol": {
		filePath: "D:/Users/Malhar/Projects/Stock Finder/frontend/src/routes/research.$symbol.tsx",
		children: void 0,
		preloads: [
			"/assets/research._symbol-D7KggDLL.js",
			"/assets/check-BfWG19CS.js",
			"/assets/sparkles-CTxyKtAy.js",
			"/assets/Sparkline-BKQUAuxe.js",
			"/assets/StatMetric-Dr14DY54.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
