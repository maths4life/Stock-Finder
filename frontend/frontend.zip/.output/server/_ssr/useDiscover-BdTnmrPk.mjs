import { s as queryKeys } from "./queryKeys-DIjJZzw5.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as fetchSectorPulse, n as fetchMarketIndicators, r as fetchPipeline, t as fetchDiscoverGroups } from "./market-Dor-peev.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useDiscover-BdTnmrPk.js
function useDiscoverGroups() {
	return useQuery({
		queryKey: queryKeys.discoverGroups,
		queryFn: fetchDiscoverGroups
	});
}
function usePipeline() {
	return useQuery({
		queryKey: queryKeys.pipeline,
		queryFn: fetchPipeline
	});
}
function useSectorPulse() {
	return useQuery({
		queryKey: queryKeys.sectorPulse,
		queryFn: fetchSectorPulse
	});
}
function useMarketIndicators() {
	return useQuery({
		queryKey: queryKeys.marketIndicators,
		queryFn: fetchMarketIndicators
	});
}
//#endregion
export { useSectorPulse as i, useMarketIndicators as n, usePipeline as r, useDiscoverGroups as t };
