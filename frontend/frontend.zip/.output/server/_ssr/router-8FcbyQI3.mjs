import { i as __toESM } from "../_runtime.mjs";
import { r as fetchCompanies, s as queryKeys } from "./queryKeys-DIjJZzw5.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { r as fetchPipeline, t as fetchDiscoverGroups } from "./market-Dor-peev.mjs";
import { t as fetchJournalEntries } from "./journal-BxEydgMM.mjs";
import { t as Route$6 } from "./research._symbol-Dr3Gdjj4.mjs";
import { n as toQueryParams, t as DEFAULT_FILTERS } from "./screener-x33smxGB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-8FcbyQI3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-4s-eHwSi.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-paper px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-mono uppercase tracking-widest text-ink-subtle",
					children: "Error 404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-display text-ink",
					children: "Page not found."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-ink-muted",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-accent px-4 py-2 text-sm font-medium text-accent-foreground transition-colors hover:brightness-110",
						children: "Back to Discover"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-paper px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-heading-xl text-ink",
					children: "This page didn't load."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-ink-muted",
					children: "Try again or head home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-accent px-4 py-2 text-sm font-medium text-accent-foreground hover:brightness-110",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md ring-1 ring-hairline bg-surface-raised px-4 py-2 text-sm font-medium text-ink hover:bg-secondary",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$5 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Quant Terminal — Morning intelligence for Indian equities" },
			{
				name: "description",
				content: "A calm, editorial research OS for Indian stocks. Discover companies worth researching today, build conviction, and record every thesis."
			},
			{
				name: "author",
				content: "Quant Terminal"
			},
			{
				property: "og:title",
				content: "Quant Terminal — Morning intelligence for Indian equities"
			},
			{
				property: "og:description",
				content: "Discover, research, and hold high-conviction Indian equities for the next 6–12 months."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$5.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$4 = () => import("./screener-CSILwkdg.mjs");
var Route$4 = createFileRoute("/screener")({
	loader: ({ context }) => context.queryClient.ensureQueryData({
		queryKey: queryKeys.companies.list(toQueryParams(DEFAULT_FILTERS, 1)),
		queryFn: () => fetchCompanies(toQueryParams(DEFAULT_FILTERS, 1))
	}),
	head: () => ({ meta: [{ title: "Screener — Quant" }, {
		name: "description",
		content: "Filter on fundamentals and technicals. See only what qualifies."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./research-cqXg2mbf.mjs");
var DEFAULT_PARAMS = {
	sort: "overallScore",
	sortDirection: "desc",
	page: 1,
	pageSize: 8
};
var Route$3 = createFileRoute("/research")({
	loader: ({ context }) => context.queryClient.ensureQueryData({
		queryKey: queryKeys.companies.list(DEFAULT_PARAMS),
		queryFn: () => fetchCompanies(DEFAULT_PARAMS)
	}),
	head: () => ({ meta: [{ title: "Research — Quant" }, {
		name: "description",
		content: "Deep, calm research briefings on Indian companies."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./journal-BoejczNw.mjs");
var Route$2 = createFileRoute("/journal")({
	loader: ({ context }) => context.queryClient.ensureQueryData({
		queryKey: queryKeys.journalEntries,
		queryFn: fetchJournalEntries
	}),
	head: () => ({ meta: [{ title: "Journal — Quant" }, {
		name: "description",
		content: "Record every thesis. Review, learn, compound."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./ideas-DO-9rd8F.mjs");
var Route$1 = createFileRoute("/ideas")({
	loader: ({ context }) => context.queryClient.ensureQueryData({
		queryKey: queryKeys.pipeline,
		queryFn: fetchPipeline
	}),
	head: () => ({ meta: [{ title: "Ideas Pipeline — Quant" }, {
		name: "description",
		content: "Watching, researching, conviction. Every idea in one board."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./routes-D0t5jnVi.mjs");
var Route = createFileRoute("/")({
	loader: ({ context }) => context.queryClient.ensureQueryData({
		queryKey: queryKeys.discoverGroups,
		queryFn: fetchDiscoverGroups
	}),
	head: () => ({ meta: [
		{ title: "Morning Intelligence — Quant" },
		{
			name: "description",
			content: "Today's most researchable Indian companies, grouped by why they matter."
		},
		{
			property: "og:title",
			content: "Morning Intelligence — Quant"
		},
		{
			property: "og:description",
			content: "A calm briefing on the Indian companies worth your attention today."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var ScreenerRoute = Route$4.update({
	id: "/screener",
	path: "/screener",
	getParentRoute: () => Route$5
});
var ResearchRoute = Route$3.update({
	id: "/research",
	path: "/research",
	getParentRoute: () => Route$5
});
var JournalRoute = Route$2.update({
	id: "/journal",
	path: "/journal",
	getParentRoute: () => Route$5
});
var IdeasRoute = Route$1.update({
	id: "/ideas",
	path: "/ideas",
	getParentRoute: () => Route$5
});
var IndexRoute = Route.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$5
});
var ResearchRouteChildren = { ResearchSymbolRoute: Route$6.update({
	id: "/$symbol",
	path: "/$symbol",
	getParentRoute: () => ResearchRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	IdeasRoute,
	JournalRoute,
	ResearchRoute: ResearchRoute._addFileChildren(ResearchRouteChildren),
	ScreenerRoute
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
