import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { i as TrendingDown, r as TrendingUp } from "../_libs/lucide-react.mjs";
import { i as cn } from "./skeleton-hHmS3eQg.mjs";
import { t as Sparkline } from "./Sparkline-tbvAtMJU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/CompanyRow-DcfI8xN3.js
var import_jsx_runtime = require_jsx_runtime();
/** Dense, single-line-ish row presentation used in list-style sections (Discover feed, Research library). */
function CompanyRow({ company: c, description, className }) {
	const positive = c.changePct >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/research/$symbol",
		params: { symbol: c.symbol },
		className: cn("group grid grid-cols-12 gap-6 py-5 hairline-b last:border-b-0 hover:bg-secondary/40 transition-colors -mx-3 px-3 rounded-md", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "col-span-12 sm:col-span-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-[15px] text-ink group-hover:text-accent transition-colors",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-[11px] text-ink-subtle mt-0.5",
					children: [
						c.exchange,
						":",
						c.symbol
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "col-span-12 sm:col-span-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13.5px] leading-relaxed text-ink-muted text-pretty line-clamp-2",
					children: description ?? c.rationale
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-ink-subtle mt-2 uppercase tracking-widest",
					children: c.sector
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "col-span-12 sm:col-span-3 flex sm:flex-col items-center sm:items-end justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [positive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3 text-positive" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-3 text-negative" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("text-sm font-medium tabular-nums", positive ? "text-positive" : "text-negative"),
							children: [
								positive ? "+" : "",
								c.changePct.toFixed(2),
								"%"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
						data: c.spark,
						tone: positive ? "positive" : "negative",
						width: 90,
						height: 24,
						className: "hidden sm:block my-1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-ink-subtle",
						children: c.marketCap
					})
				]
			})
		]
	});
}
//#endregion
export { CompanyRow as t };
