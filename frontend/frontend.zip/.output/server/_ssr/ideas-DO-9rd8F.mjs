import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { f as Inbox } from "../_libs/lucide-react.mjs";
import { n as ErrorState, r as Skeleton, t as AppShell } from "./skeleton-hHmS3eQg.mjs";
import { n as PageHeader, t as EmptyState } from "./EmptyState-CsxZQot_.mjs";
import { t as Sparkline } from "./Sparkline-tbvAtMJU.mjs";
import { r as usePipeline } from "./useDiscover-BdTnmrPk.mjs";
import { t as useCompaniesForSymbols } from "./useCompaniesForSymbols-CIFhzwmg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ideas-DO-9rd8F.js
var import_jsx_runtime = require_jsx_runtime();
var stageHint = {
	Watching: {
		hint: "Something caught your attention",
		color: "bg-hairline-strong"
	},
	Researching: {
		hint: "Building the thesis",
		color: "bg-[oklch(0.65_0.14_75)]"
	},
	Conviction: {
		hint: "Ready to hold for 6–12 months",
		color: "bg-positive"
	}
};
function Ideas() {
	const { data: columns = [], isPending, isError, refetch } = usePipeline();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 py-12 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Ideas board",
				title: "Every idea in one place, moving forward.",
				description: "Watchlist and journal, merged. Track meaningful change, not price ticks.",
				className: "mb-12"
			}),
			isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-28" }), Array.from({ length: 2 }).map((_, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32 w-full rounded-xl" }, j))]
				}, i))
			}),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Couldn't load your pipeline.",
				onRetry: () => refetch()
			}),
			!isPending && !isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelineColumnView, { column: col }, col.stage))
			})
		]
	}) });
}
function PipelineColumnView({ column: col }) {
	const meta = stageHint[col.stage];
	const { data: companies = [] } = useCompaniesForSymbols(col.items.map((i) => i.symbol));
	const companyBySymbol = new Map(companies.map((c) => [c.symbol, c]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-fade-up",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full " + meta.color }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-eyebrow text-ink",
							children: col.stage
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-mono text-ink-subtle",
							children: col.items.length
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-ink-subtle mb-4",
				children: meta.hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					col.items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: Inbox,
						title: "Nothing here yet",
						description: `Move a company to "${col.stage}" from its research page.`,
						className: "py-8 rounded-xl border border-dashed border-hairline-strong"
					}),
					col.items.map((item) => {
						const c = companyBySymbol.get(item.symbol);
						if (!c) return null;
						const positive = c.changePct >= 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/research/$symbol",
							params: { symbol: item.symbol },
							className: "block p-5 rounded-xl ring-1 ring-hairline bg-surface-raised hover:ring-hairline-strong hover:shadow-card-hover transition-all group",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3 mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-heading-md group-hover:text-accent transition-colors",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-[10px] text-ink-subtle mt-1",
										children: [
											c.exchange,
											":",
											c.symbol
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
										data: c.spark,
										tone: positive ? "positive" : "negative",
										width: 60,
										height: 24
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-ink-muted leading-snug mb-3",
									children: [
										"\"",
										item.note,
										"\""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[10px] uppercase tracking-widest text-ink-subtle",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.ago }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: positive ? "text-positive" : "text-negative",
										children: [
											positive ? "▲" : "▼",
											" ",
											Math.abs(c.changePct).toFixed(2),
											"%"
										]
									})]
								})
							]
						}, item.symbol);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "w-full py-3 rounded-xl border border-dashed border-hairline-strong text-xs text-ink-subtle hover:text-ink hover:border-accent transition-colors",
						children: "+ Add company"
					})
				]
			})
		]
	});
}
//#endregion
export { Ideas as component };
