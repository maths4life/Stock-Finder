import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { _ as Check, a as Sparkles, b as ArrowLeft, n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { c as useCompanyPrices, i as cn, n as ErrorState, r as Skeleton, s as useCompany, t as AppShell } from "./skeleton-hHmS3eQg.mjs";
import { t as Sparkline } from "./Sparkline-tbvAtMJU.mjs";
import { t as StatMetric } from "./StatMetric-BIOFTiGt.mjs";
import { t as Route } from "./research._symbol-Dr3Gdjj4.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research._symbol-De_TQma8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEMES = {
	light: "",
	dark: ".dark"
};
var ChartContext = import_react.createContext(null);
function useChart() {
	const context = import_react.useContext(ChartContext);
	if (!context) throw new Error("useChart must be used within a <ChartContainer />");
	return context;
}
var ChartContainer = import_react.forwardRef(({ id, className, children, config, ...props }, ref) => {
	const uniqueId = import_react.useId();
	const chartId = `chart-${id || uniqueId.replace(/:/g, "")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContext.Provider, {
		value: { config },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			"data-chart": chartId,
			ref,
			className: cn("flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-none [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-sector]:outline-none [&_.recharts-surface]:outline-none", className),
			...props,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartStyle, {
				id: chartId,
				config
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children })]
		})
	});
});
ChartContainer.displayName = "Chart";
var ChartStyle = ({ id, config }) => {
	const colorConfig = Object.entries(config).filter(([, config]) => config.theme || config.color);
	if (!colorConfig.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { dangerouslySetInnerHTML: { __html: Object.entries(THEMES).map(([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig.map(([key, itemConfig]) => {
		const color = itemConfig.theme?.[theme] || itemConfig.color;
		return color ? `  --color-${key}: ${color};` : null;
	}).join("\n")}
}
`).join("\n") } });
};
var ChartTooltip = Tooltip;
var ChartTooltipContent = import_react.forwardRef(({ active, payload, className, indicator = "dot", hideLabel = false, hideIndicator = false, label, labelFormatter, labelClassName, formatter, color, nameKey, labelKey }, ref) => {
	const { config } = useChart();
	const tooltipLabel = import_react.useMemo(() => {
		if (hideLabel || !payload?.length) return null;
		const [item] = payload;
		const key = `${labelKey || item?.dataKey || item?.name || "value"}`;
		const itemConfig = getPayloadConfigFromPayload(config, item, key);
		const value = !labelKey && typeof label === "string" ? config[label]?.label || label : itemConfig?.label;
		if (labelFormatter) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-medium", labelClassName),
			children: labelFormatter(value, payload)
		});
		if (!value) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-medium", labelClassName),
			children: value
		});
	}, [
		label,
		labelFormatter,
		payload,
		hideLabel,
		labelClassName,
		config,
		labelKey
	]);
	if (!active || !payload?.length) return null;
	const nestLabel = payload.length === 1 && indicator !== "dot";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: cn("grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl", className),
		children: [!nestLabel ? tooltipLabel : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-1.5",
			children: payload.filter((item) => item.type !== "none").map((item, index) => {
				const key = `${nameKey || item.name || item.dataKey || "value"}`;
				const itemConfig = getPayloadConfigFromPayload(config, item, key);
				const indicatorColor = color || item.payload.fill || item.color;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground", indicator === "dot" && "items-center"),
					children: formatter && item?.value !== void 0 && item.name ? formatter(item.value, item.name, item, index, item.payload) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [itemConfig?.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(itemConfig.icon, {}) : !hideIndicator && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)", {
							"h-2.5 w-2.5": indicator === "dot",
							"w-1": indicator === "line",
							"w-0 border-[1.5px] border-dashed bg-transparent": indicator === "dashed",
							"my-0.5": nestLabel && indicator === "dashed"
						}),
						style: {
							"--color-bg": indicatorColor,
							"--color-border": indicatorColor
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex flex-1 justify-between leading-none", nestLabel ? "items-end" : "items-center"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [nestLabel ? tooltipLabel : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: itemConfig?.label || item.name
							})]
						}), item.value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono font-medium tabular-nums text-foreground",
							children: item.value.toLocaleString()
						})]
					})] })
				}, item.dataKey);
			})
		})]
	});
});
ChartTooltipContent.displayName = "ChartTooltip";
var ChartLegendContent = import_react.forwardRef(({ className, hideIcon = false, payload, verticalAlign = "bottom", nameKey }, ref) => {
	const { config } = useChart();
	if (!payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("flex items-center justify-center gap-4", verticalAlign === "top" ? "pb-3" : "pt-3", className),
		children: payload.filter((item) => item.type !== "none").map((item) => {
			const key = `${nameKey || item.dataKey || "value"}`;
			const itemConfig = getPayloadConfigFromPayload(config, item, key);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground"),
				children: [itemConfig?.icon && !hideIcon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(itemConfig.icon, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 w-2 shrink-0 rounded-[2px]",
					style: { backgroundColor: item.color }
				}), itemConfig?.label]
			}, item.value);
		})
	});
});
ChartLegendContent.displayName = "ChartLegend";
function getPayloadConfigFromPayload(config, payload, key) {
	if (typeof payload !== "object" || payload === null) return;
	const payloadPayload = "payload" in payload && typeof payload.payload === "object" && payload.payload !== null ? payload.payload : void 0;
	let configLabelKey = key;
	if (key in payload && typeof payload[key] === "string") configLabelKey = payload[key];
	else if (payloadPayload && key in payloadPayload && typeof payloadPayload[key] === "string") configLabelKey = payloadPayload[key];
	return configLabelKey in config ? config[configLabelKey] : config[key];
}
var RANGES = [
	"1M",
	"3M",
	"6M",
	"1Y",
	"5Y",
	"ALL"
];
var chartConfig = { close: {
	label: "Close",
	color: "var(--color-accent)"
} };
/** Research page's "Price History" section (Module 3). Renders only
* fields the backend actually returns from `prices_daily` — no derived
* or invented values. */
function PriceChart({ data, range, onRangeChange, isLoading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-end gap-1 mb-4",
			children: RANGES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => onRangeChange(r),
				className: "px-2 py-1 rounded text-[11px] font-mono uppercase tracking-wider transition-colors " + (r === range ? "bg-accent text-accent-foreground" : "text-ink-subtle hover:text-ink hover:bg-secondary"),
				children: r
			}, r))
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[220px] rounded-xl bg-secondary/40 animate-pulse" }),
		!isLoading && data.length < 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-[220px] rounded-xl ring-1 ring-hairline grid place-items-center text-sm text-ink-muted",
			children: "No price history available for this range."
		}),
		!isLoading && data.length >= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
			config: chartConfig,
			className: "h-[220px] w-full aspect-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					left: 0,
					right: 0,
					top: 8,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "priceFill",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "var(--color-accent)",
							stopOpacity: .25
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "var(--color-accent)",
							stopOpacity: 0
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						vertical: false,
						strokeOpacity: .15
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "date",
						tickLine: false,
						axisLine: false,
						minTickGap: 40,
						tickFormatter: (v) => new Date(v).toLocaleDateString("en-IN", {
							month: "short",
							day: "numeric"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tickLine: false,
						axisLine: false,
						width: 56,
						domain: ["auto", "auto"],
						tickFormatter: (v) => `₹${v.toLocaleString("en-IN")}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, {
						labelFormatter: (v) => new Date(v).toLocaleDateString("en-IN", {
							day: "numeric",
							month: "short",
							year: "numeric"
						}),
						formatter: (value) => [`₹${Number(value).toLocaleString("en-IN")}`, "Close"]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						dataKey: "close",
						type: "monotone",
						stroke: "var(--color-accent)",
						fill: "url(#priceFill)",
						strokeWidth: 1.5
					})
				]
			})
		})
	] });
}
function ResearchDetail() {
	const { symbol } = Route.useParams();
	const { data: c, isPending, isError, error, refetch } = useCompany(symbol);
	const [priceRange, setPriceRange] = (0, import_react.useState)("6M");
	const { data: prices, isPending: pricesPending } = useCompanyPrices(symbol, priceRange);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-4xl mx-auto px-6 py-10 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "inline-flex items-center gap-1.5 text-[11px] uppercase tracking-widest text-ink-subtle hover:text-ink transition-colors mb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3" }), " Back to Discover"]
			}),
			isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchDetailSkeleton, {}),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-10",
				children: error?.status === 404 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center py-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-heading-xl",
						children: "Company not in library"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-ink-muted",
						children: "Try searching with ⌘K."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
					description: "Couldn't load this company's research.",
					onRetry: () => refetch()
				})
			}),
			c && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "animate-fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] font-mono uppercase tracking-widest text-ink-subtle",
									children: [
										c.exchange,
										":",
										c.symbol
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-ink-subtle",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono uppercase tracking-widest text-ink-subtle",
									children: c.sector
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-display md:text-display-lg text-balance",
							children: c.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-lg text-ink-muted leading-snug max-w-[52ch] text-pretty",
							children: c.rationale
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 grid grid-cols-2 md:grid-cols-5 gap-y-6 hairline-t hairline-b py-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Price",
									value: `₹${c.price.toLocaleString("en-IN")}`,
									sub: `${c.changePct >= 0 ? "+" : ""}${c.changePct.toFixed(2)}%`,
									tone: c.changePct >= 0 ? "positive" : "negative",
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Market Cap",
									value: c.marketCap,
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "P/E",
									value: c.pe.toFixed(1) + "x",
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "RoE",
									value: c.roe.toFixed(1) + "%",
									tone: "positive",
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Div Yield",
									value: c.divYield.toFixed(2) + "%",
									size: "lg"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-y-6 py-6 hairline-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Overall Score",
									value: c.overallScore.toFixed(0) + "/100",
									tone: "positive",
									size: "lg",
									highlight: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Fundamental Score",
									value: c.fundamentalScore.toFixed(0) + "/100",
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Technical Score",
									value: c.technicalScore.toFixed(0) + "/100",
									size: "lg"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-y-6 py-6 hairline-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Risk Level",
									value: c.riskLevel,
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Expected Return",
									value: c.expectedReturnPct.toFixed(1) + "%",
									tone: "positive",
									size: "lg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
									label: "Investment Horizon",
									value: `${c.investmentHorizonMonths}mo`,
									size: "lg"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
								data: c.spark,
								tone: c.changePct >= 0 ? "positive" : "negative",
								fill: true,
								width: 800,
								height: 80,
								className: "w-full h-20"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 space-y-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Price History",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceChart, {
								data: prices ?? [],
								range: priceRange,
								onRangeChange: setPriceRange,
								isLoading: pricesPending
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Fundamentals",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 md:grid-cols-4 gap-y-6 hairline-t pt-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "P/B",
										value: c.pb.toFixed(2) + "x"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "ROCE",
										value: c.roce.toFixed(1) + "%"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Debt/Equity",
										value: c.debtToEquity.toFixed(2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "EPS",
										value: "₹" + c.eps.toFixed(2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Revenue Growth",
										value: c.salesGrowthPct.toFixed(1) + "%",
										tone: c.salesGrowthPct >= 0 ? "positive" : "negative"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Profit Growth",
										value: c.profitGrowthPct.toFixed(1) + "%",
										tone: c.profitGrowthPct >= 0 ? "positive" : "negative"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Promoter Holding",
										value: c.promoterHoldingPct.toFixed(1) + "%"
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Technicals",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 md:grid-cols-4 gap-y-6 hairline-t pt-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "RSI (14)",
										value: c.rsi.toFixed(0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Above 50 DMA",
										value: c.aboveEma50 ? "Yes" : "No",
										tone: c.aboveEma50 ? "positive" : "negative"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Above 200 DMA",
										value: c.aboveEma200 ? "Yes" : "No",
										tone: c.aboveEma200 ? "positive" : "negative"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Golden Cross",
										value: c.goldenCross ? "Yes" : "No",
										tone: c.goldenCross ? "positive" : "neutral"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Volume Breakout",
										value: c.volumeBreakout ? "Yes" : "No",
										tone: c.volumeBreakout ? "positive" : "neutral"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Trend",
										value: c.trend,
										tone: c.trend === "Uptrend" ? "positive" : c.trend === "Downtrend" ? "negative" : "neutral"
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Verdict",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl ring-1 ring-hairline bg-secondary/40 p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] uppercase tracking-widest font-medium text-accent",
										children: c.verdict
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-heading-lg leading-snug text-ink text-pretty",
									children: c.verdictSummary
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Business",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[15px] leading-relaxed text-ink text-pretty",
								children: c.businessSummary
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Quarterly Financials",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-6 hairline-t pt-6",
								children: c.quarterlyFinancials.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] uppercase tracking-widest text-ink-subtle",
										children: q.quarter
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-heading-lg mt-1 tabular-nums",
										children: [
											"₹",
											q.revenueCr.toLocaleString("en-IN"),
											"cr"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-ink-muted mt-0.5",
										children: [
											"Revenue · Net Profit ₹",
											q.netProfitCr.toLocaleString("en-IN"),
											"cr",
											q.ebitdaMarginPct > 0 && ` · EBITDA ${q.ebitdaMarginPct.toFixed(1)}%`
										]
									})
								] }, q.quarter))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Shareholding",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl ring-1 ring-hairline overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-5 px-5 py-2.5 bg-secondary/50 text-[10px] uppercase tracking-widest text-ink-subtle",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quarter" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-right",
											children: "Promoter"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-right",
											children: "FII"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-right",
											children: "DII"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-right",
											children: "Public"
										})
									]
								}), c.shareholdingTrend.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-5 px-5 py-3 text-sm hairline-t",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-ink-muted",
											children: row.quarter
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-right font-mono tabular-nums",
											children: [row.promoter.toFixed(1), "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-right font-mono tabular-nums",
											children: [row.fii.toFixed(1), "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-right font-mono tabular-nums",
											children: [row.dii.toFixed(1), "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-right font-mono tabular-nums",
											children: [row.public.toFixed(1), "%"]
										})
									]
								}, row.quarter))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Why AI Selected",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl ring-1 ring-hairline bg-secondary/40 p-6 flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-accent mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[15px] leading-relaxed text-ink text-pretty",
									children: c.rationale
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Pros",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-3",
								children: c.pros.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 text-[15px] text-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-positive mt-1 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s })]
								}, s))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Cons",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-3",
								children: c.cons.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 text-[15px] text-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-[oklch(0.6_0.15_60)] mt-1 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s })]
								}, s))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							label: "Checklist",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-xl ring-1 ring-hairline divide-y divide-hairline overflow-hidden",
								children: c.checklist.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4 px-5 py-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-4 rounded-full grid place-items-center " + (item.done ? "bg-positive text-white" : "ring-1 ring-hairline-strong"),
										children: item.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-2.5",
											strokeWidth: 3
										}) : null
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm " + (item.done ? "text-ink" : "text-ink-muted"),
										children: item.label
									})]
								}, item.label))
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-14 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/ideas",
						className: "px-4 py-2 rounded-md bg-accent text-accent-foreground text-sm font-medium hover:brightness-110",
						children: "Add to Pipeline"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/journal",
						className: "px-4 py-2 rounded-md ring-1 ring-hairline text-sm font-medium hover:bg-secondary",
						children: "Start Thesis"
					})]
				})
			] })
		]
	}) });
}
function Section({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid grid-cols-1 sm:grid-cols-[140px_1fr] gap-3 sm:gap-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-mono uppercase tracking-[0.18em] text-ink-subtle pt-2",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children })]
	});
}
function ResearchDetailSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-fade-up",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-32 mb-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14 w-3/4 mb-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-1/2 mb-10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 md:grid-cols-5 gap-6 py-6 hairline-t hairline-b",
				children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-2.5 w-14" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-20" })]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20 w-full mt-8" })
		]
	});
}
//#endregion
export { ResearchDetail as component };
