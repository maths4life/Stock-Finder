import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Sparkline-tbvAtMJU.js
var import_jsx_runtime = require_jsx_runtime();
var toneToVar = {
	positive: "var(--color-positive)",
	negative: "var(--color-negative)",
	neutral: "var(--color-ink-muted)",
	accent: "var(--color-accent)"
};
function Sparkline({ data, width = 120, height = 32, tone = "accent", strokeWidth = 1.25, fill = false, className }) {
	if (data.length < 2) return null;
	const min = Math.min(...data);
	const range = Math.max(...data) - min || 1;
	const stepX = width / (data.length - 1);
	const path = `M ${data.map((v, i) => {
		const x = i * stepX;
		const y = height - (v - min) / range * (height - 2) - 1;
		return `${x.toFixed(2)},${y.toFixed(2)}`;
	}).join(" L ")}`;
	const areaPath = `${path} L ${width},${height} L 0,${height} Z`;
	const color = toneToVar[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${width} ${height}`,
		width,
		height,
		className,
		preserveAspectRatio: "none",
		children: [fill && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: areaPath,
			fill: color,
			opacity: .08
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: path,
			fill: "none",
			stroke: color,
			strokeWidth,
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
//#endregion
export { Sparkline as t };
