import { a as fetchCompany, o as fetchCompanyPrices, s as queryKeys } from "./queryKeys-DIjJZzw5.mjs";
import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research._symbol-Dr3Gdjj4.js
var $$splitComponentImporter = () => import("./research._symbol-De_TQma8.mjs");
var Route = createFileRoute("/research/$symbol")({
	loader: async ({ params, context }) => {
		await context.queryClient.ensureQueryData({
			queryKey: queryKeys.companies.detail(params.symbol),
			queryFn: () => fetchCompany(params.symbol)
		}).catch(() => void 0);
		await context.queryClient.ensureQueryData({
			queryKey: queryKeys.companies.prices(params.symbol, "6M"),
			queryFn: () => fetchCompanyPrices(params.symbol, "6M")
		}).catch(() => void 0);
	},
	head: ({ params }) => ({ meta: [{ title: `${params.symbol} — Research | Quant` }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
