//#region node_modules/.nitro/vite/services/ssr/assets/screener-x33smxGB.js
var DEFAULT_FILTERS = {
	sector: "All",
	minRoe: 0,
	minRoce: 0,
	minEpsGrowth: 0,
	minSalesGrowth: 0,
	maxPe: 200,
	maxDebtToEquity: 3,
	minPromoterHolding: 0,
	aboveEma200: false,
	aboveEma50: false,
	volumeBreakout: false,
	riskLevel: "Any",
	horizon: "Any"
};
function toQueryParams(filters, page) {
	return {
		sector: filters.sector,
		riskLevel: filters.riskLevel,
		horizon: filters.horizon,
		minRoe: filters.minRoe,
		minRoce: filters.minRoce,
		minEpsGrowth: filters.minEpsGrowth,
		minSalesGrowth: filters.minSalesGrowth,
		maxPe: filters.maxPe,
		maxDebtToEquity: filters.maxDebtToEquity,
		minPromoterHolding: filters.minPromoterHolding,
		aboveEma200: filters.aboveEma200,
		aboveEma50: filters.aboveEma50,
		volumeBreakout: filters.volumeBreakout,
		sort: "overallScore",
		sortDirection: "desc",
		page,
		pageSize: 6
	};
}
//#endregion
export { toQueryParams as n, DEFAULT_FILTERS as t };
