import { i as fetchCompaniesBySymbols } from "./queryKeys-DIjJZzw5.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useCompaniesForSymbols-CIFhzwmg.js
function useCompaniesForSymbols(symbols) {
	return useQuery({
		queryKey: [
			"companies",
			"by-symbols",
			[...symbols].sort().join(",")
		],
		queryFn: () => fetchCompaniesBySymbols(symbols),
		enabled: symbols.length > 0
	});
}
//#endregion
export { useCompaniesForSymbols as t };
