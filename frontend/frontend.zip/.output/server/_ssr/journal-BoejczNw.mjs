import { s as queryKeys } from "./queryKeys-DIjJZzw5.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as NotebookPen } from "../_libs/lucide-react.mjs";
import { n as ErrorState, r as Skeleton, t as AppShell } from "./skeleton-hHmS3eQg.mjs";
import { n as PageHeader, t as EmptyState } from "./EmptyState-CsxZQot_.mjs";
import { t as useCompaniesForSymbols } from "./useCompaniesForSymbols-CIFhzwmg.mjs";
import { t as fetchJournalEntries } from "./journal-BxEydgMM.mjs";
import { t as StatMetric } from "./StatMetric-BIOFTiGt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-BoejczNw.js
var import_jsx_runtime = require_jsx_runtime();
function useJournalEntries() {
	return useQuery({
		queryKey: queryKeys.journalEntries,
		queryFn: fetchJournalEntries
	});
}
function Journal() {
	const { data: entries = [], isPending, isError, refetch } = useJournalEntries();
	const { data: companies = [] } = useCompaniesForSymbols(entries.map((e) => e.symbol));
	const companyBySymbol = new Map(companies.map((c) => [c.symbol, c]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-4xl mx-auto px-6 py-12 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Research journal",
				title: "Write down what you believe, and why.",
				description: "The most under-rated tool in investing. Six months from now, you'll be glad you did.",
				className: "mb-14"
			}),
			isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-10",
				children: Array.from({ length: 2 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-32" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-9 w-2/3" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full" })
					]
				}, i))
			}),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Couldn't load your journal.",
				onRetry: () => refetch()
			}),
			!isPending && !isError && entries.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: NotebookPen,
				title: "No entries yet",
				description: "Start a thesis on any research page to see it here."
			}),
			!isPending && !isError && entries.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-14",
				children: entries.map((e) => {
					const c = companyBySymbol.get(e.symbol);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "hairline-b pb-14 last:border-b-0 animate-fade-up",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/research/$symbol",
									params: { symbol: e.symbol },
									className: "text-[11px] uppercase tracking-widest text-accent hover:underline underline-offset-2",
									children: c ? `${c.name} · ${c.exchange}:${c.symbol}` : e.symbol
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-mono text-ink-subtle",
									children: e.date
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-heading-xl text-balance",
								children: e.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid grid-cols-2 sm:grid-cols-4 gap-6 hairline-b pb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Conviction",
										value: `${e.conviction}/5`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Target Price",
										value: `₹${e.targetPrice.toLocaleString("en-IN")}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Expected Return",
										value: `${e.expectedReturnPct}%`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatMetric, {
										label: "Horizon",
										value: `${e.horizonMonths} months`
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 grid grid-cols-1 sm:grid-cols-[120px_1fr] gap-3 sm:gap-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-mono uppercase tracking-[0.18em] text-ink-subtle pt-1",
									children: "Thesis"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[15px] leading-relaxed text-ink text-pretty",
									children: e.thesis
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid grid-cols-1 sm:grid-cols-[120px_1fr] gap-3 sm:gap-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-mono uppercase tracking-[0.18em] text-ink-subtle pt-1",
									children: "Catalysts"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1.5",
									children: e.catalysts.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "text-[15px] text-ink flex gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-accent",
												children: "→"
											}),
											" ",
											cat
										]
									}, cat))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid grid-cols-1 sm:grid-cols-[120px_1fr] gap-3 sm:gap-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-mono uppercase tracking-[0.18em] text-ink-subtle pt-1",
									children: "Risks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1.5",
									children: e.risks.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "text-[15px] text-ink-muted flex gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-negative",
												children: "×"
											}),
											" ",
											r
										]
									}, r))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid grid-cols-1 sm:grid-cols-[120px_1fr] gap-3 sm:gap-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-mono uppercase tracking-[0.18em] text-ink-subtle pt-1",
									children: "What would make you sell"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[15px] text-ink-muted leading-relaxed text-pretty",
									children: e.sellTrigger
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex items-center gap-2 text-[11px] text-ink-subtle",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-accent" }),
									"Review reopens ",
									e.reviewDue
								]
							})
						]
					}, e.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "w-full mt-10 py-6 rounded-xl border border-dashed border-hairline-strong text-sm font-medium text-ink-subtle hover:text-ink hover:border-accent transition-colors",
				children: "+ Start a new thesis"
			})
		]
	}) });
}
//#endregion
export { Journal as component };
