//#region node_modules/.nitro/vite/services/ssr/assets/queryKeys-DIjJZzw5.js
/**
* A tiny stand-in for a real HTTP client (e.g. a Supabase client or fetch
* wrapper). Every function in `lib/api/*` funnels through `resolveMock` so
* that:
*
*   1. Every "endpoint" is async, matching what a real network call looks
*      like — components and hooks never assume synchronous data.
*   2. Loading and error states can be exercised and designed for today,
*      before a backend exists.
*   3. Swapping the implementation later is a one-line change per function:
*      replace `resolveMock(() => ...)` with `await supabase.from(...)`.
*
* None of this should leak into components — they only ever see
* `Promise<T>` via the hooks in `src/hooks`.
*/
var SIMULATED_LATENCY_MS = 380;
var ApiError = class extends Error {
	status;
	constructor(message, status = 500) {
		super(message);
		this.name = "ApiError";
		this.status = status;
	}
};
/**
* Wraps a synchronous mock computation in an async, network-shaped call.
* Set `NEXT_PUBLIC_MOCK_FAILURE_RATE`-style behaviour via `failureRate` when
* a screen needs to be tested against error states.
*/
function resolveMock(compute, opts) {
	const latency = opts?.latencyMs ?? SIMULATED_LATENCY_MS;
	const failureRate = opts?.failureRate ?? 0;
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			if (failureRate > 0 && Math.random() < failureRate) {
				reject(new ApiError("The request could not be completed. Please try again."));
				return;
			}
			try {
				resolve(compute());
			} catch (err) {
				reject(err instanceof Error ? err : new ApiError("Unknown error"));
			}
		}, latency);
	});
}
var API_URL = "http://127.0.0.1:8000";
/**
* GET /companies
* Backend does the fetch/search (Module 1). Pagination is still applied
* here on the returned array — that's a display concern, not screening/
* ranking/filtering, so it's fine to keep client-side for now. Sorting
* and heavier filtering move server-side in Module 4 (Screener).
*/
async function fetchCompanies(params = {}) {
	const qs = new URLSearchParams();
	if (params.search) qs.set("search", params.search);
	const response = await fetch(`${API_URL}/companies?${qs.toString()}`);
	if (!response.ok) throw new Error("Failed to fetch companies");
	const companies = await response.json();
	const page = params.page ?? 1;
	const pageSize = params.pageSize ?? 10;
	const start = (page - 1) * pageSize;
	const end = start + pageSize;
	return {
		items: companies.slice(start, end),
		page,
		pageSize,
		total: companies.length,
		totalPages: Math.ceil(companies.length / pageSize)
	};
}
/**
* GET /company/{symbol}
*/
async function fetchCompany(symbol) {
	const response = await fetch(`${API_URL}/company/${symbol}`);
	if (response.status === 404) throw new ApiError(`No company found for symbol "${symbol}"`, 404);
	if (!response.ok) throw new Error("Failed to fetch company");
	return response.json();
}
/**
* GET /company/{symbol}/prices — Module 3 Price History section. Doesn't
* 404 on an unknown symbol (see routes/companies.py's docstring); an
* empty array is the honest response and the chart renders its own
* empty state for that case.
*/
async function fetchCompanyPrices(symbol, range = "6M") {
	const qs = new URLSearchParams({ range });
	const response = await fetch(`${API_URL}/company/${symbol}/prices?${qs.toString()}`);
	if (!response.ok) throw new Error("Failed to fetch price history");
	return response.json();
}
/**
* Used by search bar. Search now happens in Postgres (ILIKE on name/symbol)
* via the `search` query param, not a client-side .filter() over the full
* list.
*/
async function searchCompanies(query, limit = 8) {
	const qs = new URLSearchParams({
		search: query,
		limit: String(limit)
	});
	const response = await fetch(`${API_URL}/companies?${qs.toString()}`);
	if (!response.ok) throw new Error("Failed to fetch companies");
	return response.json();
}
/**
* Used for dropdowns (e.g. sector filter options).
*/
async function fetchAllCompanies() {
	const response = await fetch(`${API_URL}/companies`);
	if (!response.ok) throw new Error("Failed to fetch companies");
	return response.json();
}
/**
* Used by watchlist/portfolio. A lookup by exact symbol, not screening or
* ranking, so it's fine to filter client-side over the already-fetched list.
*/
async function fetchCompaniesBySymbols(symbols) {
	return (await fetchAllCompanies()).filter((c) => symbols.includes(c.symbol.toUpperCase()));
}
/**
* Central query-key factory. Keeping keys in one place avoids typos/drift
* once more screens start reading the same resources, and makes cache
* invalidation after a future mutation (e.g. "add to pipeline") predictable.
*/
var queryKeys = {
	companies: {
		all: ["companies"],
		list: (params) => [
			"companies",
			"list",
			params
		],
		detail: (symbol) => [
			"companies",
			"detail",
			symbol
		],
		search: (query) => [
			"companies",
			"search",
			query
		],
		prices: (symbol, range) => [
			"companies",
			"prices",
			symbol,
			range
		]
	},
	discoverGroups: ["discover-groups"],
	pipeline: ["pipeline"],
	sectorPulse: ["sector-pulse"],
	marketIndicators: ["market-indicators"],
	journalEntries: ["journal-entries"]
};
//#endregion
export { fetchCompany as a, resolveMock as c, fetchCompaniesBySymbols as i, searchCompanies as l, fetchAllCompanies as n, fetchCompanyPrices as o, fetchCompanies as r, queryKeys as s, ApiError as t };
