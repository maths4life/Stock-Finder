import { t as ApiError } from "./queryKeys-DIjJZzw5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-Dor-peev.js
var API_URL = "http://127.0.0.1:8000";
/** GET /discover/groups */
async function fetchDiscoverGroups() {
	const response = await fetch(`${API_URL}/discover/groups`);
	if (!response.ok) throw new ApiError("Failed to fetch discover groups", response.status);
	return response.json();
}
/** GET /pipeline */
async function fetchPipeline() {
	const response = await fetch(`${API_URL}/pipeline`);
	if (!response.ok) throw new ApiError("Failed to fetch pipeline", response.status);
	return response.json();
}
/** GET /sectors/pulse */
async function fetchSectorPulse() {
	const response = await fetch(`${API_URL}/sectors/pulse`);
	if (!response.ok) throw new ApiError("Failed to fetch sector pulse", response.status);
	return response.json();
}
/** GET /market/indicators */
async function fetchMarketIndicators() {
	const response = await fetch(`${API_URL}/market/indicators`);
	if (!response.ok) throw new ApiError("Failed to fetch market indicators", response.status);
	return response.json();
}
//#endregion
export { fetchSectorPulse as i, fetchMarketIndicators as n, fetchPipeline as r, fetchDiscoverGroups as t };
